  module.exports = {
    // Constants to track the size of the warehouse
    NUM_WAREHOUSE_ROWS: 25,
    NUM_ROW_SQUARES:10,

    // Max number of items that can be stored in a lot
    MAX_LOT_AMOUNT: 100000
  };

